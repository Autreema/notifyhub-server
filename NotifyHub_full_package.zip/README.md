
NotifyHub - Zoho Cliq Extension Package
======================================

This package contains a ready-to-edit Zoho Cliq extension you can upload to the Developer Console.
After upload, replace the placeholder webhook URL in manifest.json with your publicly reachable server URL.

Files included:
- manifest.json         : extension metadata and components
- widget/index.html     : Dashboard widget
- functions/createWebhook.deluge : sample Deluge function (optional)
- functions/sendTest.deluge       : sample Deluge function (optional)
- server/                : optional Node.js webhook server (deploy to your host)
- icons/                 : placeholder icons
- README.md              : this file

How to use:
1. Edit manifest.json to set your webhook URL (webhook_url field).
2. Zip the package (or use this zip) and upload it in Zoho Cliq Developer Console -> Create Extension -> Upload Package.
3. Create or paste Deluge functions in the console (or use the Node server).
4. Install the extension in your org and test the commands.

If you need help deploying the Node.js server, contact me and I will provide step-by-step instructions.
